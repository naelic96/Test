
// frontend-example.js

import Tracker from '@openreplay/tracker';
import { WebTracerProvider } from '@opentelemetry/sdk-trace-web';
import { ConsoleSpanExporter, SimpleSpanProcessor } from '@opentelemetry/sdk-trace-base';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';

const tracker = new Tracker({
  projectKey: 'my_project_key', // sostituisci con il tuo
});
tracker.start();

// Inizializza OpenTelemetry
const provider = new WebTracerProvider();
const exporter = new OTLPTraceExporter({
  url: 'http://localhost:4318/v1/traces', // OTLP HTTP
});

provider.addSpanProcessor(new SimpleSpanProcessor(exporter));
provider.addSpanProcessor(new SimpleSpanProcessor(new ConsoleSpanExporter()));
provider.register();

const tracer = provider.getTracer('frontend-example');

document.getElementById('startBtn').addEventListener('click', () => {
  const span = tracer.startSpan('user-clicked-start');
  tracker.setMetadata("trace_id", span.spanContext().traceId);
  setTimeout(() => {
    span.end();
  }, 500);
});
