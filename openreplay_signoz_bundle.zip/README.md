
# OpenReplay + Signoz + OpenTelemetry (Local Setup)

Questo bundle contiene una soluzione locale completa per:

- **OpenReplay** (session replay)
- **Signoz** (metrics, traces, logs)
- **OpenTelemetry Collector**
- Esempi di applicazioni strumentate in **JS (frontend)**, **Node.js (backend)** e **.NET**

---

## Prerequisiti

- Docker e Docker Compose installati
- Node.js (per backend JS) e .NET SDK 7.0 (per esempio .NET)
- Connessione Internet per scaricare le immagini Docker

---

## 1. Avvio dei servizi

### OpenReplay

```bash
docker-compose -f docker-compose.openreplay.yml up -d
```

Accesso a:

- Tracker: [http://localhost:3000](http://localhost:3000)
- MinIO (storage sessioni): [http://localhost:9000](http://localhost:9000)

### Signoz + OpenTelemetry Collector

```bash
docker-compose -f docker-compose.signoz.yml up -d
```

Accesso a:

- Signoz UI: [http://localhost:3301](http://localhost:3301)

---

## 2. App Frontend (JS)

Percorso: `frontend/frontend-example.js`

Installa le dipendenze:

```bash
npm install @openreplay/tracker @opentelemetry/sdk-trace-web @opentelemetry/exporter-trace-otlp-http
```

Integra il codice nel tuo frontend app (es. React/Vue).

---

## 3. App Backend (Node.js)

Percorso: `backend/backend-example.js`

Installa le dipendenze:

```bash
npm install express @opentelemetry/sdk-trace-node @opentelemetry/exporter-trace-otlp-http @opentelemetry/instrumentation @opentelemetry/instrumentation-express
```

Esegui:

```bash
node backend-example.js
```

---

## 4. App .NET (ASP.NET Core)

Percorso: `dotnet/`

Costruisci ed esegui il container:

```bash
docker build -t dotnet-app ./dotnet
docker run -p 5000:80 dotnet-app
```

Assicurati che Signoz sia attivo sulla porta `4317` (OTLP gRPC).

---

## Note

- Modifica il `PROJECT_KEY` in `docker-compose.openreplay.yml` e nei frontend con il tuo valore corretto
- Signoz raccoglie dati da frontend/backend via OTLP (porte 4317 gRPC / 4318 HTTP)

---

## Supporto

Per configurazioni avanzate o deploy su Kubernetes/OpenShift, chiedi pure!
