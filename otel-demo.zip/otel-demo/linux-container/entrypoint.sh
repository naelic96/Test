
#!/bin/bash
echo "Linux container is running"
while true; do
  echo "Heartbeat log from Linux container"
  sleep 5
done
