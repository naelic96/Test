
// backend-example.js

const { NodeTracerProvider } = require('@opentelemetry/sdk-trace-node');
const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-http');
const { SimpleSpanProcessor } = require('@opentelemetry/sdk-trace-base');
const { registerInstrumentations } = require('@opentelemetry/instrumentation');
const { ExpressInstrumentation } = require('@opentelemetry/instrumentation-express');
const express = require('express');

// OpenTelemetry setup
const provider = new NodeTracerProvider();
const exporter = new OTLPTraceExporter({
  url: 'http://localhost:4318/v1/traces', // OTLP HTTP
});
provider.addSpanProcessor(new SimpleSpanProcessor(exporter));
provider.register();

registerInstrumentations({
  instrumentations: [new ExpressInstrumentation()],
});

const tracer = provider.getTracer('backend-example');
const app = express();

app.get('/', (req, res) => {
  const span = tracer.startSpan('handle-root');
  setTimeout(() => {
    span.end();
    res.send('Hello from backend with OTel!');
  }, 200);
});

app.listen(3001, () => {
  console.log('Backend listening on port 3001');
});
