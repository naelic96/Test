
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class App {
    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:postgresql://postgres:5432/postgres", "postgres", "postgres");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT NOW()");
            if (rs.next()) {
                System.out.println("PostgreSQL Time: " + rs.getString(1));
            }
        } catch (Exception e) {
            System.err.println("Exception occurred: " + e.getMessage());
        }

        // Simulate error
        if (true) {
            throw new RuntimeException("Simulated exception from Java app");
        }
    }
}
