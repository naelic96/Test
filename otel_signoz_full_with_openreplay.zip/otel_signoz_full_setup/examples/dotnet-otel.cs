
using OpenTelemetry;
using OpenTelemetry.Trace;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenTelemetryTracing(tracerProviderBuilder =>
{
    tracerProviderBuilder
        .AddAspNetCoreInstrumentation()
        .AddHttpClientInstrumentation()
        .SetResourceBuilder(ResourceBuilder.CreateDefault().AddService("MyDotnetApp"))
        .AddOtlpExporter(o =>
        {
            o.Endpoint = new Uri("http://localhost:4319");
        });
});

var app = builder.Build();
app.MapGet("/", () => "Hello from .NET with OTEL");
app.Run();
