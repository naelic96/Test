
# Osservabilità con Signoz e OpenTelemetry

Questo pacchetto include:

- Signoz (monitoraggio e tracciamento)
- OpenTelemetry Collector configurato
- Esempi di strumentazione per Node.js, .NET

## Come avviare

1. Clona o estrai il contenuto del pacchetto.
2. Esegui il comando:

```
docker compose up -d
```

3. Accedi a Signoz: http://localhost:3301

## Esempi inclusi

- `examples/nodejs-otel.js`: Node.js con OTEL
- `examples/dotnet-otel.cs`: .NET con OTEL

## Requisiti

- Docker + Docker Compose installati
