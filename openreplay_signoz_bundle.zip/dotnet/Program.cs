
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OpenTelemetry;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

var builder = WebApplication.CreateBuilder(args);

// OpenTelemetry config
builder.Services.AddOpenTelemetryTracing(b =>
{
    b.SetResourceBuilder(ResourceBuilder.CreateDefault().AddService("dotnet-example"))
     .AddAspNetCoreInstrumentation()
     .AddHttpClientInstrumentation()
     .AddOtlpExporter(otlp =>
     {
         otlp.Endpoint = new Uri("http://localhost:4317");
     });
});

builder.Services.AddControllers();

var app = builder.Build();

app.MapGet("/", () => "Hello from .NET with OpenTelemetry!");

app.Run();
