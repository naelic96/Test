
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Data.SqlClient;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using OpenTelemetry.Metrics;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenTelemetry()
    .ConfigureResource(r => r.AddService("dotnet-app"))
    .WithTracing(b => b
        .AddAspNetCoreInstrumentation()
        .AddSqlClientInstrumentation()
        .AddOtlpExporter(o => o.Endpoint = new Uri("http://otel-collector:4317")))
    .WithMetrics(b => b
        .AddRuntimeInstrumentation()
        .AddAspNetCoreInstrumentation()
        .AddOtlpExporter(o => o.Endpoint = new Uri("http://otel-collector:4317")));

var app = builder.Build();

app.MapGet("/", () => "Hello from .NET!");

app.MapGet("/db", async () => {
    try {
        var conn = new SqlConnection("Server=sqlserver;Database=master;User Id=sa;Password=Your_password123;");
        await conn.OpenAsync();
        var command = new SqlCommand("SELECT GETDATE()", conn);
        var result = await command.ExecuteScalarAsync();
        return $"SQL Server Time: {result}";
    } catch (Exception ex) {
        return $"Error: {ex.Message}";
    }
});

app.MapGet("/exception", () => {
    throw new Exception("Simulated exception from .NET");
});

app.Run();
