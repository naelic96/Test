
# Osservabilità con Signoz, OpenTelemetry e OpenReplay

Questo pacchetto include:

- Signoz (monitoraggio e tracciamento)
- OpenTelemetry Collector configurato
- OpenReplay per replay delle sessioni utente
- Esempi di strumentazione per Node.js, .NET e frontend JS

## Come avviare

1. Clona o estrai il contenuto del pacchetto.
2. Esegui il comando:

```
docker compose up -d
```

3. Accedi a:
   - Signoz: http://localhost:3301
   - OpenReplay Tracker (da integrare nel frontend): http://localhost:3000

## Esempi inclusi

- `examples/nodejs-otel.js`: Node.js con OTEL
- `examples/dotnet-otel.cs`: .NET con OTEL
- `examples/frontend-openreplay.html`: JS frontend con OpenReplay

## Requisiti

- Docker + Docker Compose installati
